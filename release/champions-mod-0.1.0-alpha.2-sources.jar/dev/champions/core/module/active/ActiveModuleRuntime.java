package dev.champions.core.module.active;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * Narrow capability surface for explicitly active modules. Commands are an
 * enum so modules cannot submit arbitrary chat or server commands.
 */
public interface ActiveModuleRuntime {
	CompletionStage<ChatTranscript> execute(ChatCommandRequest request);

	static ActiveModuleRuntime disabled() {
		return request -> CompletableFuture.completedFuture(new ChatTranscript(
			request.command(), List.of(), Status.UNSUPPORTED, "Active client runtime is unavailable."));
	}

	enum SafeChatCommand {
		LIST_PLUGINS("plugins", "/plugins");

		private final String wireCommand;
		private final String displayCommand;

		SafeChatCommand(String wireCommand, String displayCommand) {
			this.wireCommand = wireCommand;
			this.displayCommand = displayCommand;
		}

		public String wireCommand() { return wireCommand; }
		public String displayCommand() { return displayCommand; }
	}

	record ChatCommandRequest(SafeChatCommand command, int timeoutTicks, int maxMessages) {
		public ChatCommandRequest {
			Objects.requireNonNull(command, "command");
			if (timeoutTicks < 20 || timeoutTicks > 200) throw new IllegalArgumentException("timeoutTicks must be 20-200");
			if (maxMessages < 1 || maxMessages > 20) throw new IllegalArgumentException("maxMessages must be 1-20");
		}
	}

	record ChatTranscript(SafeChatCommand command, List<String> messages, Status status, String detail) {
		public ChatTranscript {
			Objects.requireNonNull(command, "command");
			messages = messages == null ? List.of() : List.copyOf(messages);
			Objects.requireNonNull(status, "status");
			detail = detail == null ? "" : detail;
		}
	}

	enum Status { COMPLETED, TIMED_OUT, DISCONNECTED, BUSY, UNSUPPORTED, ERROR }
}
