package dev.champions.core.module.builtin;

import dev.champions.core.module.Finding;
import dev.champions.core.module.ModuleContext;
import dev.champions.core.module.ModuleOption;
import dev.champions.core.module.ModuleResult;
import dev.champions.core.module.active.ActiveModuleRuntime;
import dev.champions.core.module.active.ActiveResearchModule;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionStage;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Sends exactly /plugins once and observes the resulting server chat output. */
public final class ChatPluginEnumeratorModule implements ActiveResearchModule {
	private static final Pattern PLUGIN_LINE = Pattern.compile("(?i).*?plugins?\\s*(?:\\((\\d+)\\))?\\s*:\\s*(.*)");
	private static final Pattern PLUGIN_NAME = Pattern.compile("[A-Za-z0-9_.-]{1,64}");
	private static final List<String> DENIAL_MARKERS = List.of(
		"no permission", "do not have permission", "don't have permission", "not permitted",
		"unknown command", "unknown or incomplete command", "cannot use this command"
	);

	@Override public String id() { return "auxiliary/scanner/chat_plugin_enumerator"; }
	@Override public String name() { return "Chat plugin enumerator"; }
	@Override public String description() {
		return "Sends the standard /plugins command once and captures the resulting server game-message output. No aliases, namespaces, retries, or bypass attempts.";
	}
	@Override public List<ModuleOption> options() {
		return List.of(
			new ModuleOption("RHOST", "CURRENT", true, false, "Must match the current allowlisted connection"),
			new ModuleOption("CONFIRM", "", true, true, "One-run authorization phrase: I_HAVE_AUTHORIZATION"),
			new ModuleOption("TIMEOUT_TICKS", "60", false, false, "Capture window, 20-200 client ticks"),
			new ModuleOption("MAX_MESSAGES", "8", false, false, "Maximum game messages captured, 1-20"),
			new ModuleOption("INCLUDE_RAW", "true", false, false, "Include the bounded raw chat transcript")
		);
	}

	@Override
	public CompletionStage<ModuleResult> runActive(ModuleContext context, Map<String, String> options, ActiveModuleRuntime runtime) {
		int timeout = boundedInt(options.get("TIMEOUT_TICKS"), 60, 20, 200);
		int maxMessages = boundedInt(options.get("MAX_MESSAGES"), 8, 1, 20);
		boolean includeRaw = Boolean.parseBoolean(options.getOrDefault("INCLUDE_RAW", "true"));
		var request = new ActiveModuleRuntime.ChatCommandRequest(
			ActiveModuleRuntime.SafeChatCommand.LIST_PLUGINS, timeout, maxMessages);
		return runtime.execute(request).thenApply(transcript -> analyze(transcript, includeRaw));
	}

	private ModuleResult analyze(ActiveModuleRuntime.ChatTranscript transcript, boolean includeRaw) {
		List<Finding> findings = new ArrayList<>();
		findings.add(new Finding(Finding.Severity.INFO, "Chat action",
			transcript.command().displayCommand() + " sent once; capture status " + transcript.status().name().toLowerCase(Locale.ROOT),
			"Use only with an account and server for which this command test is authorized."));

		if (transcript.status() == ActiveModuleRuntime.Status.BUSY
			|| transcript.status() == ActiveModuleRuntime.Status.DISCONNECTED
			|| transcript.status() == ActiveModuleRuntime.Status.UNSUPPORTED
			|| transcript.status() == ActiveModuleRuntime.Status.ERROR) {
			findings.add(new Finding(Finding.Severity.INFO, "Runtime result", transcript.detail(),
				"Connect to the authorized target and ensure no other active module is capturing chat."));
			return new ModuleResult("Chat enumeration did not run", findings);
		}

		boolean denied = transcript.messages().stream()
			.map(s -> s.toLowerCase(Locale.ROOT))
			.anyMatch(line -> DENIAL_MARKERS.stream().anyMatch(line::contains));
		Set<String> plugins = extractPlugins(transcript.messages());
		if (denied) {
			findings.add(new Finding(Finding.Severity.PASS, "Command exposure",
				"The current permission context did not receive a plugin list.",
				"Keep plugin inventory commands restricted; verify each public role independently."));
		} else if (!plugins.isEmpty()) {
			findings.add(new Finding(Finding.Severity.LOW, "Plugin names exposed",
				plugins.size() + " candidate(s): " + String.join(", ", plugins),
				"Review whether plugin inventory should be visible to this permission group. Treat names as hints, not proof of installed versions or vulnerabilities."));
		} else {
			findings.add(new Finding(Finding.Severity.INFO, "Plugin parsing",
				"No standard Bukkit-style plugin list was recognized in the bounded response window.",
				"Use an administrator-supplied server inventory for authoritative plugin names and versions."));
		}

		if (includeRaw) {
			String raw = transcript.messages().isEmpty() ? "<no game messages captured>" : String.join(" | ", transcript.messages());
			findings.add(new Finding(Finding.Severity.INFO, "Bounded raw transcript", limit(raw, 1_500),
				"The capture may include unrelated server game messages; verify manually before reporting."));
		}
		return new ModuleResult("Chat plugin enumeration completed", findings);
	}

	static Set<String> extractPlugins(List<String> messages) {
		Set<String> plugins = new LinkedHashSet<>();
		for (String raw : messages) {
			String line = raw.replaceAll("§.", "").strip();
			Matcher matcher = PLUGIN_LINE.matcher(line);
			if (!matcher.matches()) continue;
			String payload = matcher.group(2).strip();
			if (payload.isEmpty()) continue;
			for (String candidate : payload.split(",")) {
				String name = candidate.strip().replaceFirst("^[+\\-*]\\s*", "");
				int space = name.indexOf(' ');
				if (space > 0) name = name.substring(0, space);
				if (PLUGIN_NAME.matcher(name).matches()) plugins.add(name);
			}
		}
		return plugins;
	}

	private static int boundedInt(String value, int fallback, int min, int max) {
		try { return Math.max(min, Math.min(max, Integer.parseInt(value))); }
		catch (RuntimeException ignored) { return fallback; }
	}

	private static String limit(String value, int max) {
		return value.length() <= max ? value : value.substring(0, max) + "…";
	}
}
