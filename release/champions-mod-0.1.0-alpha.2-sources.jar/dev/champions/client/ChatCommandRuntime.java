package dev.champions.client;

import dev.champions.core.module.active.ActiveModuleRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/** Client-thread implementation of the single fixed chat-command capability. */
final class ChatCommandRuntime implements ActiveModuleRuntime {
	private static final int IDLE_TICKS_AFTER_MESSAGE = 12;
	private long tick;
	private Pending pending;

	@Override
	public synchronized CompletionStage<ChatTranscript> execute(ChatCommandRequest request) {
		if (pending != null) return completed(request, Status.BUSY, "Another chat capture is already active.");
		Minecraft client = Minecraft.getInstance();
		if (client.getConnection() == null || !client.getConnection().isAcceptingMessages()) {
			return completed(request, Status.DISCONNECTED, "No active server connection can accept a command.");
		}

		Pending next = new Pending(request, tick + request.timeoutTicks());
		pending = next;
		try {
			// The enum supplies the only possible wire value: "plugins".
			client.getConnection().sendCommand(request.command().wireCommand());
		} catch (RuntimeException error) {
			pending = null;
			next.future.complete(new ChatTranscript(request.command(), List.of(), Status.ERROR, safeMessage(error)));
		}
		return next.future;
	}

	synchronized void onGameMessage(Component message, boolean overlay) {
		if (pending == null || overlay) return;
		String text = sanitize(message.getString());
		if (text.isBlank()) return;
		pending.messages.add(text);
		pending.idleDeadline = tick + IDLE_TICKS_AFTER_MESSAGE;
		if (pending.messages.size() >= pending.request.maxMessages()) complete(Status.COMPLETED, "Message limit reached.");
	}

	synchronized void tick(Minecraft client) {
		tick++;
		if (pending == null) return;
		if (client.getConnection() == null || !client.getConnection().isAcceptingMessages()) {
			complete(Status.DISCONNECTED, "Connection ended during capture.");
		} else if (!pending.messages.isEmpty() && tick >= pending.idleDeadline) {
			complete(Status.COMPLETED, "Response capture became idle.");
		} else if (tick >= pending.deadline) {
			complete(Status.TIMED_OUT, "Bounded response window expired.");
		}
	}

	private void complete(Status status, String detail) {
		Pending done = pending;
		if (done == null) return;
		pending = null;
		done.future.complete(new ChatTranscript(done.request.command(), List.copyOf(done.messages), status, detail));
	}

	private static CompletionStage<ChatTranscript> completed(ChatCommandRequest request, Status status, String detail) {
		return CompletableFuture.completedFuture(new ChatTranscript(request.command(), List.of(), status, detail));
	}

	private static String sanitize(String value) {
		String cleaned = value == null ? "" : value.replace('\r', ' ').replace('\n', ' ').strip();
		return cleaned.length() <= 500 ? cleaned : cleaned.substring(0, 500) + "…";
	}

	private static String safeMessage(Throwable error) {
		String value = error.getMessage();
		return value == null || value.isBlank() ? error.getClass().getSimpleName() : sanitize(value);
	}

	private static final class Pending {
		private final ChatCommandRequest request;
		private final long deadline;
		private final List<String> messages = new ArrayList<>();
		private final CompletableFuture<ChatTranscript> future = new CompletableFuture<>();
		private long idleDeadline = Long.MAX_VALUE;

		private Pending(ChatCommandRequest request, long deadline) {
			this.request = request;
			this.deadline = deadline;
		}
	}
}
