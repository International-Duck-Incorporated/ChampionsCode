package dev.champions.core.module;

import java.util.List;

/** Immutable snapshot of state already advertised to the connected client. */
public record ModuleContext(
	boolean connected,
	boolean integratedServer,
	boolean memoryTransport,
	boolean onlineMode,
	String serverAddress,
	String serverBrand,
	String advertisedVersion,
	int advertisedProtocol,
	long pingMillis,
	int onlinePlayers,
	String resourcePackPolicy,
	String playerName,
	String playerPosition,
	String dimension,
	int clientFps,
	float averageReceivedPackets,
	float averageSentPackets,
	List<String> advertisedCommands,
	List<CommandDescriptor> advertisedCommandDetails
) {
	public ModuleContext {
		serverAddress = safe(serverAddress);
		serverBrand = safe(serverBrand);
		advertisedVersion = safe(advertisedVersion);
		resourcePackPolicy = safe(resourcePackPolicy);
		playerName = safe(playerName);
		playerPosition = safe(playerPosition);
		dimension = safe(dimension);
		advertisedCommands = advertisedCommands == null ? List.of() : List.copyOf(advertisedCommands);
		advertisedCommandDetails = advertisedCommandDetails == null ? List.of() : List.copyOf(advertisedCommandDetails);
	}

	/** Compatibility constructor for contexts that only need root names. */
	public ModuleContext(
		boolean connected, boolean integratedServer, boolean memoryTransport, boolean onlineMode,
		String serverAddress, String serverBrand, String advertisedVersion, int advertisedProtocol,
		long pingMillis, int onlinePlayers, String resourcePackPolicy, String playerName,
		String playerPosition, String dimension, int clientFps, float averageReceivedPackets,
		float averageSentPackets, List<String> advertisedCommands
	) {
		this(connected, integratedServer, memoryTransport, onlineMode, serverAddress, serverBrand,
			advertisedVersion, advertisedProtocol, pingMillis, onlinePlayers, resourcePackPolicy,
			playerName, playerPosition, dimension, clientFps, averageReceivedPackets,
			averageSentPackets, advertisedCommands, List.of());
	}

	private static String safe(String value) {
		return value == null || value.isBlank() ? "unknown" : value;
	}
}
